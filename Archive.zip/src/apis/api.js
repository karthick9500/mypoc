
import * as React from 'react';


export function getList(selectedOption) {
  console.log('logging here')
  return fetch('https://reqres.in/api/users/'+selectedOption)
    .then(data => data.json())
}

// export function getallEmp() {
//   console.log('logging here')
//   return fetch('https://dummy.restapiexample.com/api/v1/employees')
//     .then(data => data.json())
// }



export function getpublicResp(setAge) {
  console.log('logging here animals')
  console.log(setAge)
  return fetch('https://api.publicapis.org/entries?category='+setAge)
    .then(data => data.json())
}
