import { DataGrid } from '@mui/x-data-grid';
import { getpublicResp } from "../../apis/api"
import * as React from 'react';
import Box from '@mui/material/Box';


const columns = [
  { field: 'API', headerName: 'ID', width: 90 },
  {
    field: 'Auth',
    headerName: 'First name',
    width: 150,
    editable: true,
  },
  {
    field: 'Category',
    headerName: 'Last name',
    width: 150,
    editable: true,
  },
  {
    field: 'Cors',
    headerName: 'Age',
    type: 'number',
    width: 110,
    editable: true,
  },
  {
    field: 'Description',
    headerName: 'Full name',
    description: 'This column has a value getter and is not sortable.',
    sortable: false,
    width: 160,
    valueGetter: (params) =>
      `${params.row.firstName || ''} ${params.row.lastName || ''}`,
  },
  {
    field: 'HTTPS',
    headerName: 'Age',
    width: 110,
    editable: true,
  },
  {
    field: 'Link',
    headerName: 'Age',

    width: 110,
    editable: true,
  },
];


export default function DataGridDemo(props) {
  const [papidata, setpapidata] = React.useState([]);
  React.useEffect(() => {
    getpublicResp(props.sharedData)
      .then(json => setpapidata(json.entries))
      .catch(error => console.error(error));
  }, [props.sharedData]);
  console.log(props.sharedData)
  
  // const newResponseData = Object.keys(papidata).reduce((array, key) => {
  //   return [...array, { key: papidata[key] }];
  // }, []);
  // console.log(newResponseData)
  return (
    <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={papidata}
        columns={columns}
        getRowId={(papidata) =>  papidata.Link}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5]}
        checkboxSelection
        disableRowSelectionOnClick
      />
    </Box>
  );
}
