import * as React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import * as apis from '../../apis/api'
import DataGridDemo from "../component/table"

export default function CustomizedSelects() {
  const [age, setAge] = React.useState('');
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const animals = ["Animals", "Anti-Malware", "Art & Design", "Cryptocurrency", "Data Validation"];

  return (
    <div>
      <FormControl sx={{ m: 1, minWidth: 120 }} variant="standard">
        <InputLabel id="demo-customized-select-label">Select a DC</InputLabel>
        <Select
          labelId="demo-customized-select-label"
          id="demo-customized-select"
          value={age}
          onChange={handleChange}
        >
          
          {animals.map(animal => (
            <MenuItem value={animal}>{animal}</MenuItem>
          ))}

        </Select>
      </FormControl>
      <DataGridDemo sharedData={age} ></DataGridDemo>
    </div>

  );
}


