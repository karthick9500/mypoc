import React from 'react';

type Props = {};

const AnalyticsPage = (props: Props) => {
  return (
    <div>AnalyticsPage</div>
  );
};

export default AnalyticsPage;