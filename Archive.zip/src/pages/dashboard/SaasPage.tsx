import React from 'react';

type Props = {};

const SaasPage = (props: Props) => {
  return (
    <div>SaasPage</div>
  );
};

export default SaasPage;