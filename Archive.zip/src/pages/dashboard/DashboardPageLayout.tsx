import { Outlet } from "react-router-dom";

const DashboardPageLayout = () => {
  return (
    <><Outlet /></>
  );
};

export default DashboardPageLayout;