import React from 'react';

type Props = {};

const ChangelogPage = (props: Props) => {
  return (
    <div>ChangelogPage</div>
  );
};

export default ChangelogPage;