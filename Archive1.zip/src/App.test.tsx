import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';
import { msalConfig } from "./authConfig.js";
import { PublicClientApplication, EventType } from "@azure/msal-browser";

const msalInstance = new PublicClientApplication(msalConfig);

test('renders learn react link', () => {
  render(<App instance={msalInstance}/>);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
