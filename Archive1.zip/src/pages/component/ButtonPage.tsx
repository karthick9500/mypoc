import React from 'react';

type Props = {};

const ButtonPage = (props: Props) => {
  return (
    <div>ButtonPage</div>
  );
};

export default ButtonPage;