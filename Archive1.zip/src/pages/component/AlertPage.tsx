import React from 'react';

type Props = {};

const AlertPage = (props: Props) => {
  return (
    <div>AlertPage</div>
  );
};

export default AlertPage;