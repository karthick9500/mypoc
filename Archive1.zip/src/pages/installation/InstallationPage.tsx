import React from 'react';

type Props = {};

const InstallationPage = (props: Props) => {
  return (
    <div>InstallationPage</div>
  );
};

export default InstallationPage;