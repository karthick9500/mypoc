import React from 'react';

type Props = {};

const DefaultPage = (props: Props) => {
  return (
    <div>DefaultPage</div>
  );
};

export default DefaultPage;