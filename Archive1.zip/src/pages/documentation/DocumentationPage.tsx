import React from 'react';

type Props = {};

const DocumentationPage = (props: Props) => {
  return (
    <div>DocumentationPage</div>
  );
};

export default DocumentationPage;